utilities_main.R:
  Main simulation code
utilities_generate.R:
  setting(): Compute covariance matrix and coefficient vectors for data generation
  data.poission(): Generate data following the Poisson model
utilities_estimate.R:
  score_fn(): Calculate Score vector
  RP.tests(): Compute classical test statistics
  simulation(): Performs simulation for particular iteration