## The logistic model-----------------------

logi<-function(x){
  y = NULL
  y = exp(x)/(1+exp(x))
  return(y) 
}
logi.deri<-function(x){
  y = NULL
  y = exp(x)/((1+exp(x))^2)
  return(y)
}
esti.logi<-function(omega,c,n,rho){
  c_0=mean(logi.deri(omega*rnorm(1000,0,1)))
  mean.y=mean(logi((omega*rnorm(1000,0,1))))
  sigma_2=mean.y-mean.y^2-c^2*(omega^2)*c_0^2
  power=sqrt((n*(1-rho))/(2*rho))*(c_0^2)*c^2*omega^2
  return(pnorm(qnorm(0.05)+(power/sigma_2)))
}

c_seq=seq(from=0.1,to=1, by=0.1)
omega_seq=seq(from=0,to=2.7, by=0.05)
record_logi=matrix(NA,length(c_seq),length(omega_seq))

for (j in 1: length(omega_seq)){
  for (i in 1: length(c_seq)){
    record_logi[i,j]=esti.logi(omega_seq[j],c_seq[i],n=600,rho=0.4)
    }
}

par<-colorRamp(c("blue","red"))
color_seq=par(seq(from=0, to=1, len=length(c_seq)))

plot(omega_seq, record_logi[1,],type = "l", lty=1, col=rgb(color_seq[1,1],color_seq[1,2],color_seq[1,3],255,maxColorValue = 255),
     xlab="",ylab="", ylim=c(0,1), xlim=c(0,1))
for(i in 2:length(c_seq)){
  col_tempt=rgb(color_seq[i,1],color_seq[i,2],color_seq[i,3],255,maxColorValue = 255)
  lines(omega_seq, record_logi[i,], type = "l", lty=1, col=col_tempt)
}
colors_range = rgb(color_seq[,1],color_seq[,2],color_seq[,3],255,maxColorValue = 255)
legend("bottomright",legend=paste0("d=", c_seq[length(c_seq):1]), 
       col = colors_range[length(colors_range):1], pch = 19, bg=rgb(1,1,1,1,1),cex=1, ncol=1, y.intersp=0.2,text.width=0.05, adj=c(0.2))
grid()
 
 
## Poission model -----------------------

esti.pois<-function(omega,c,n,rho){
  c_0=exp((omega^2)/2)
  sigma_2=exp(omega^2)*(exp(omega^2)+exp(-(omega^2)/2)-1-(c^2)*omega^2)
  power=sqrt((n*(1-rho))/(2*rho))*(c_0^2)*(c^2)*omega^2
  return(pnorm(qnorm(0.05)+(power/sigma_2)))
}

c_seq=seq(from=0.1,to=1, by=0.1)
omega_seq=seq(from=0,to=2.4, by=0.05)
record_pois=matrix(NA,length(c_seq),length(omega_seq))

for (j in 1: length(omega_seq)){
  for (i in 1: length(c_seq)){
    record_pois[i,j]=esti.pois(omega_seq[j],c_seq[i],n=600,rho=0.4)
  }
}

par<-colorRamp(c("blue","red"))
color_seq=par(seq(from=0, to=1, len=length(c_seq)))

plot(omega_seq, record_pois[1,],type = "l", lty=1, col=rgb(color_seq[1,1],color_seq[1,2],color_seq[1,3],255,maxColorValue = 255),
     xlab="",ylab="", ylim=c(0,1), xlim=c(0,1))
for(i in 2:length(c_seq)){
  col_tempt=rgb(color_seq[i,1],color_seq[i,2],color_seq[i,3],255,maxColorValue = 255)
  lines(omega_seq, record_pois[i,], type = "l", lty=1, col=col_tempt)
}
colors_range = rgb(color_seq[,1],color_seq[,2],color_seq[,3],255,maxColorValue = 255)
legend("bottomright",legend=paste0("d=", c_seq[length(c_seq):1]), 
       col = colors_range[length(colors_range):1], pch = 19, bg=rgb(1,1,1,1,1),cex=1, ncol=1, y.intersp=0.2,text.width=0.05, adj=c(0.2))
grid()

 
 